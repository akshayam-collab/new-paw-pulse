/* PawPulse shared JavaScript.
   Everything here is local/mock prototype behavior: there is no backend, database, paid API, or real AI API. */

const animals={
  Max:{type:'Dog',age:'4 years',status:'Stable',activity:78,location:'Home safe zone',appetite:'Normal',rest:'Normal',health:92,notes:'Usual evening activity and appetite.'},
  Luna:{type:'Cat',age:'2 years',status:'Stable',activity:69,location:'Garden safe zone',appetite:'Normal',rest:'Normal',health:89,notes:'Routine and rest pattern are within her demo baseline.'},
  Clover:{type:'Rabbit',age:'1 year',status:'Potential concern',activity:34,location:'Indoor habitat',appetite:'Reduced',rest:'Longer inactive periods',health:61,notes:'Demo baseline deviation: lower activity, reduced appetite, reduced fecal-output observations, and longer inactive periods.'}
};

const stories=[
 {id:'rabbit-1',user:'caregiver_17',title:'Clover stopped eating for part of the day',animal:'Rabbit',tags:['rabbit','appetite','monitoring'],story:'I noticed my rabbit was much quieter than usual and was not interested in food during the afternoon. I compared what I was seeing with the notes I normally keep and decided to monitor closely rather than assume what was happening.',noticed:'Less interest in food, lower activity and fewer normal observations.',did:'Recorded the changes, checked the environment, and contacted a veterinary professional for advice.',afterward:'The situation was assessed by a professional and I continued recording normal patterns afterward.',learned:'Keeping baseline observations made it easier to explain what had changed.'},
 {id:'dog-1',user:'walkwatcher',title:'A small change in my dog’s usual walk',animal:'Dog',tags:['dog','activity','routine'],story:'My dog usually follows the same energetic routine on our evening walk. One day he moved more slowly and spent more time resting. I did not try to diagnose the reason; I recorded the difference and paid closer attention.',noticed:'Lower activity compared with his normal routine.',did:'Recorded the time and observations and contacted a veterinary professional when I remained concerned.',afterward:'His routine returned to normal after the issue was addressed.',learned:'Knowing an individual animal’s usual pattern gives useful context.'},
 {id:'bird-1',user:'featherfriend',title:'Recording breathing observations helped my vet conversation',animal:'Bird',tags:['bird','breathing','records'],story:'I noticed a breathing-related change that was not typical for my bird. Instead of relying on memory, I wrote down when I saw it and what else had changed.',noticed:'An unusual breathing observation and a change from the normal routine.',did:'Recorded observations and sought professional veterinary guidance.',afterward:'I was able to give the veterinarian a clearer timeline.',learned:'Simple, consistent notes can make a professional conversation more specific.'}
];

const pageLinks=['index.html','about.html','app.html','learn.html','community.html','ai.html','evidence.html','veterinary.html','reports.html','location.html','device.html','alerts.html','wellness.html','settings.html'];
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];

function setupNav(){
  const path=location.pathname.split('/').pop()||'index.html';
  $$('.navlinks a').forEach(a=>{if(a.getAttribute('href')===path)a.setAttribute('aria-current','page')});
  $('#menuToggle')?.addEventListener('click',()=>$('#navLinks')?.classList.toggle('open'));
}

function logoSVG(){return `<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="20" cy="19" r="7" fill="currentColor"/><circle cx="44" cy="19" r="7" fill="currentColor"/><circle cx="13" cy="33" r="7" fill="currentColor"/><circle cx="51" cy="33" r="7" fill="currentColor"/><path d="M32 27c-8 0-14 6-14 14 0 7 6 11 14 11s14-4 14-11c0-8-6-14-14-14Z" fill="currentColor"/><path d="M5 39h11l4-8 5 15 5-10 5 6h10l4-4 10 0" fill="none" stroke="#67dada" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`}

function injectAI(){
  if($('#aiFab')) return;
  const fab=document.createElement('button');fab.id='aiFab';fab.className='ai-fab';fab.type='button';fab.setAttribute('aria-label','Open PawPulse AI Companion');fab.innerHTML=logoSVG();
  const panel=document.createElement('section');panel.id='aiPanel';panel.className='ai-panel';panel.setAttribute('aria-label','PawPulse AI Companion quick panel');
  panel.innerHTML=`<div class="ai-panel-head"><h2>PawPulse AI Companion</h2><button id="aiClose" class="btn btn-secondary btn-small" type="button">Close</button></div><div id="aiQuickMessages" class="ai-messages"><div class="bubble bot">I can explain PawPulse demo data, community stories, learning content, evidence, reports, and settings. I do not diagnose animals.</div></div><div class="ai-compose"><input id="aiQuickInput" aria-label="Ask PawPulse AI" placeholder="Ask about Clover, stories, evidence…"><button id="aiQuickSend" class="btn btn-teal btn-small" type="button">Send</button></div><div style="padding:0 10px 10px"><a class="btn btn-secondary btn-small" href="ai.html">Open full AI Companion</a></div>`;
  document.body.append(fab,panel);
  fab.addEventListener('click',()=>{panel.classList.toggle('open');if(panel.classList.contains('open'))$('#aiQuickInput')?.focus()});
  $('#aiClose').addEventListener('click',()=>panel.classList.remove('open'));
  const send=()=>{const input=$('#aiQuickInput'),q=input.value.trim();if(!q)return;addBubble('user',q,'#aiQuickMessages');input.value='';setTimeout(()=>addBubble('bot',aiAnswer(q),'#aiQuickMessages'),250)};
  $('#aiQuickSend').addEventListener('click',send);$('#aiQuickInput').addEventListener('keydown',e=>{if(e.key==='Enter')send()});
}
function saveConversation(role,text){try{const h=JSON.parse(localStorage.getItem('pawpulseConversation')||'[]');h.push({role,text});localStorage.setItem('pawpulseConversation',JSON.stringify(h.slice(-30)))}catch(e){}}
function loadConversation(selector){try{const h=JSON.parse(localStorage.getItem('pawpulseConversation')||'[]');h.forEach(m=>addBubble(m.role,m.text,selector))}catch(e){}}
function addBubble(role,text,selector){const box=$(selector);if(!box)return;const d=document.createElement('div');d.className='bubble '+role;d.textContent=text;box.appendChild(d);box.scrollTop=box.scrollHeight;if(selector==='#aiMessages'||selector==='#aiQuickMessages')saveConversation(role,text)}
function aiAnswer(q){
  const x=q.toLowerCase();
  if(x.includes('clover')&&(x.includes('flag')||x.includes('why')))return 'PawPulse flagged Clover because the simulated data shows a meaningful deviation from Clover’s stored baseline: lower activity, reduced appetite, reduced fecal-output observations, and longer inactive periods. This is a wellness alert, not a diagnosis. Similar observations can occur with gastrointestinal problems, so veterinary assessment may be appropriate.';
  if((x.includes('rabbit')||x.includes('bunny'))&&(x.includes('eat')||x.includes('story')))return 'The prototype has an anonymous rabbit story tagged with appetite and monitoring. Open Community and filter Animal = Rabbit and Topic = appetite, then select Read Full Story.';
  if(x.includes('wellness')||x.includes('change'))return 'PawPulse compares observations with an individual animal’s usual baseline. A meaningful deviation can be highlighted for caregiver attention, but the prototype does not identify a disease or replace veterinary assessment.';
  if(x.includes('evidence')||x.includes('source'))return 'Open Evidence & Sources to see the scientific and veterinary references used by this prototype. The simulated dashboard interpretation is kept separate from those sources.';
  return 'I can explain the PawPulse demo, baseline changes, community stories, learning topics, evidence, reports, or settings. For health concerns, PawPulse is not a substitute for a veterinarian.';
}

function setupDashboard(){
  const cards=$$('.animal-card');if(!cards.length)return;
  const render=name=>{const a=animals[name];cards.forEach(c=>c.classList.toggle('selected',c.dataset.name===name));$('#selectedAnimal')?.replaceChildren(document.createTextNode(name));for(const [k,v] of Object.entries({activity:a.activity,location:a.location,appetite:a.appetite,rest:a.rest,health:a.health})){$('#v-'+k)&&($('#v-'+k).textContent=typeof v==='number'?v+'%':v)}$('#dashboardStatus')&&($('#dashboardStatus').textContent=a.status);$('#dashboardNotes')&&($('#dashboardNotes').textContent=a.notes)};
  cards.forEach(c=>c.addEventListener('click',()=>render(c.dataset.name)));render('Max');
}

function setupCommunity(){
  const list=$('#storyList');if(!list)return;const search=$('#storySearch'),type=$('#storyType'),tag=$('#storyTag');
  const render=()=>{const q=(search.value||'').toLowerCase(),t=type.value,g=tag.value;list.innerHTML='';stories.filter(s=>(!q||(s.title+' '+s.story+' '+s.tags.join(' ')).toLowerCase().includes(q))&&(!t||s.animal===t)&&(!g||s.tags.includes(g))).forEach(s=>{const c=document.createElement('article');c.className='card';c.innerHTML=`<div class="row"><span class="pill">${s.animal}</span><span class="kicker">${s.user}</span></div><h3>${s.title}</h3><p class="muted">Tags: ${s.tags.join(', ')}</p><p>${s.story}</p><a class="btn btn-secondary btn-small" href="story.html?id=${encodeURIComponent(s.id)}">Read Full Story</a>`;list.appendChild(c)});if(!list.children.length)list.innerHTML='<div class="notice">No stories match those filters.</div>'};[search,type,tag].forEach(x=>x?.addEventListener('input',render));render();
}

function setupStory(){const out=$('#storyDetail');if(!out)return;const id=new URLSearchParams(location.search).get('id')||stories[0].id,s=stories.find(x=>x.id===id)||stories[0];out.innerHTML=`<span class="pill">${s.animal}</span><p class="kicker">Anonymous username: ${s.user}</p><h1>${s.title}</h1><h2>The original story</h2><div class="story-original">${s.story}</div><div class="divider"></div><h3>What I noticed</h3><p>${s.noticed}</p><h3>What I did</h3><p>${s.did}</p><h3>What happened afterward</h3><p>${s.afterward}</p><h3>What I learned</h3><p>${s.learned}</p><div class="notice">Community content is shown in the contributor’s original wording. PawPulse does not turn community stories into AI-generated clinical explanations.</div>`}

function setupLearn(){ $$('.learn-open').forEach(b=>b.addEventListener('click',()=>location.href='learn-detail.html?topic='+encodeURIComponent(b.dataset.topic))) }

function setupForms(){
  $('#storyForm')?.addEventListener('submit',e=>{e.preventDefault();$('#storyConfirm').textContent='Your simulated anonymous story was submitted for this prototype. No real account or public profile was created.';$('#storyConfirm').classList.remove('hidden');e.target.reset()});
  $('#vetShare')?.addEventListener('click',()=>{$('#vetConfirm')?.classList.remove('hidden');showToast('Demo report prepared for sharing with a veterinarian.')});
  $('#saveSettings')?.addEventListener('click',()=>{$('#settingsSaved')?.classList.remove('hidden');showToast('Prototype settings saved locally for this session.')});
  $('#demoSaveObservation')?.addEventListener('click',()=>{showToast('Demo observation added to the local prototype timeline.');$('#observationSaved')?.classList.remove('hidden')});
}

function setupAIPage(){
  const box=$('#aiMessages'),input=$('#aiInput');if(!box||!input)return;loadConversation('#aiMessages');
  const send=()=>{const q=input.value.trim();if(!q)return;addBubble('user',q,'#aiMessages');input.value='';const history=$('#history');if(history){const item=document.createElement('li');item.textContent=q;history.prepend(item)}setTimeout(()=>addBubble('bot',aiAnswer(q),'#aiMessages'),250)};
  $('#aiSend')?.addEventListener('click',send);input.addEventListener('keydown',e=>{if(e.key==='Enter')send()});
  $('#aiMic')?.addEventListener('click',()=>{const status=$('#micStatus');if(status){status.textContent='Listening… simulated voice input is active. Say or type a question in this prototype.';setTimeout(()=>status.textContent='Voice demo complete. No audio was sent to a server.',1200)};addBubble('bot','Listening… (simulated voice interaction). No microphone recording is sent to a server in this prototype.','#aiMessages')});
  $('#aiRead')?.addEventListener('click',()=>{const last=[...box.querySelectorAll('.bubble.bot')].pop();if(last&&'speechSynthesis'in window)speechSynthesis.speak(new SpeechSynthesisUtterance(last.textContent))});
  $$('.quick-question').forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.question;send()}));
}

function setupTabs(){ $$('.tab').forEach(t=>t.addEventListener('click',()=>{const group=t.parentElement;group.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');const target=t.dataset.target;document.querySelectorAll('[data-tab-content]').forEach(c=>c.classList.toggle('hidden',c.dataset.tabContent!==target))})) }
function setupAlerts(){ $$('.alert-card').forEach(c=>c.addEventListener('click',()=>{const d=c.querySelector('.alert-detail');if(d)d.classList.toggle('hidden')})) }
function setupRange(){const r=$('#activityRange'),o=$('#rangeOut');r?.addEventListener('input',()=>o.textContent=r.value+'% simulated activity')}
function setupTopic(){
  const out=$('#topicDetail');if(!out)return;const t=new URLSearchParams(location.search).get('topic')||'Recognizing unusual behavior';
  const content={
   'Recognizing unusual behavior':['Look for meaningful changes from an animal’s own normal pattern: activity, interaction, appetite, movement, rest, elimination, or routine. A single observation does not establish a diagnosis.','Record what changed, when it started, how often it happens, and what else changed. Seek professional advice when you are concerned.'],
   'Safely observing an animal':['Observe without forcing contact or changing the environment unnecessarily. Note posture, movement, breathing appearance, appetite, water intake, elimination, and normal interactions when relevant.','Keep observations factual and avoid turning them into a diagnosis.'],
   'What to record for a veterinarian':['A useful record can include dates and times, what you observed, appetite or intake changes, activity changes, medications already prescribed, and relevant environmental changes.','Bring the timeline to a veterinarian rather than relying on memory.'],
   'Taking an animal’s temperature':['Temperature-taking methods vary by species and should follow veterinary guidance. The safest approach is to learn the appropriate method for the animal from a qualified professional.','Do not force an animal or risk injury just to obtain a measurement.'],
   'Basic first-aid awareness':['First aid is about immediate safety and getting appropriate professional help, not diagnosing the cause. Keep species-appropriate emergency contacts available.','For serious injury, breathing difficulty, collapse, poisoning, or other emergencies, contact a veterinarian or emergency service promptly.'],
   'Animal emergency situations':['Emergency signs can vary by species. Sudden severe breathing difficulty, collapse, major bleeding, poisoning concerns, seizures, or severe injury warrant urgent professional help.','Use trusted veterinary or animal-welfare guidance for species-specific instructions.']};
  const x=content[t]||content['Recognizing unusual behavior'];out.innerHTML=`<h1>${t}</h1><p>${x[0]}</p><div class="notice warn"><strong>Professional-care reminder:</strong> ${x[1]}</div><p class="muted">This PawPulse learning page is educational and not a veterinary diagnosis or treatment guide.</p>`;
}
function showToast(message){const old=$('.toast');old?.remove();const t=document.createElement('div');t.className='toast';t.textContent=message;document.body.appendChild(t);setTimeout(()=>t.remove(),2200)}

// Basic client-side link audit for development: it reports missing local HTML links in the console.
function auditLinks(){document.querySelectorAll('a[href]').forEach(a=>{const href=a.getAttribute('href');if(!href||href.startsWith('#')||href.startsWith('http')||href.startsWith('mailto:'))return;const file=href.split('?')[0].split('#')[0];if(file.endsWith('.html')&&!pageLinks.includes(file))console.warn('PawPulse link not in expected page list:',file)})}

document.addEventListener('DOMContentLoaded',()=>{setupNav();injectAI();setupDashboard();setupCommunity();setupStory();setupLearn();setupForms();setupAIPage();setupTabs();setupAlerts();setupRange();setupTopic();auditLinks();});
